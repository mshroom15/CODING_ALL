def disjoint(A,B):
    return A.isdisjoint(B)
print(disjoint({1,2},{3,4}))
print(disjoint({1,2},{2,3}))
