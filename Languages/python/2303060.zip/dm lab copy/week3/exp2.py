A = {1, 2}
B = {'x', 'y'}
cartesian = {(a, b) for a in A for b in B}
print("A× B =", cartesian)